#!/bin/sh
$ZOOKEEPER_HOME/bin/zkServer.sh start-foreground
