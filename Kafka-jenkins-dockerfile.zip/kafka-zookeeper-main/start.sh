#!/bin/bash
#/usr/sbin/init
/usr/bin/supervisord -n 
systemctl start jenkins
