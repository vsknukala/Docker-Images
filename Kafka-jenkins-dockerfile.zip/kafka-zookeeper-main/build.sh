#!/usr/bin/env bash

docker build --no-cache .
