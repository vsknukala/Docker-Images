Docker Kafka Zookeeper
======================
Docker image for Kafka message broker including Zookeeper

Build
-----
```
$ docker build .
[...]
Successfully built 9b382d40bccc
```

Run container
-------------
```
sudo docker run -d --privileged -p 2181:2181 -p 9092:9092 -p 8080:8080 -e ADVERTISED_HOST=localhost 744a7def1f7b /usr/sbin/init

Access container
---------------

sudo docker exec -it <containerId> /bin/bash
```

